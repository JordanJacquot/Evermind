﻿# Evermind : démarrage avec Windows et icône près de l'horloge.
# Chargé par Evermind.ps1, qui définit $AppDir, $ModulesDir et $MainScript.

# ---------------------------------------------------------------------------
# Démarrage avec Windows (clé « Run » de l'utilisateur, aucun droit administrateur nécessaire)
# ---------------------------------------------------------------------------
$RunKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$RunName = 'Evermind'

# Commande qui lance Evermind : Evermind.exe, ou PowerShell s'il manque (lancé par le .bat de secours,
# par exemple quand le « Contrôle intelligent des applications » de Windows bloque le .exe non signé)
function Get-LaunchCommand([switch]$Demarrage) {
    $opt = if ($Demarrage) { ' -Demarrage' } else { '' }
    if (Test-Path -LiteralPath $AppExe) { "`"$AppExe`"$opt" }
    else { "`"$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$MainScript`"$opt" }
}

function Get-AutoStartCommand { Get-LaunchCommand -Demarrage }

function Test-AutoStart {
    [bool](Get-ItemProperty -LiteralPath $RunKey -Name $RunName -ErrorAction SilentlyContinue)
}

function Set-AutoStart([bool]$On) {
    if ($EnTest) { return }
    if ($On) { New-ItemProperty -LiteralPath $RunKey -Name $RunName -Value (Get-AutoStartCommand) -PropertyType String -Force | Out-Null }
    else { Remove-ItemProperty -LiteralPath $RunKey -Name $RunName -ErrorAction SilentlyContinue }
    Set-Setting 'DemarrageWindows' $On
}

# Activé au premier lancement (les rappels ne marchent que si Evermind tourne). Ensuite, le chemin est remis
# à jour à chaque lancement, au cas où le dossier d'Evermind a été déplacé.
function Initialize-AutoStart {
    if ($EnTest) { return }
    try {
        $want = [bool](Get-Setting 'DemarrageWindows' $true)
        if ($want) {
            $cur = (Get-ItemProperty -LiteralPath $RunKey -Name $RunName -ErrorAction SilentlyContinue).$RunName
            if ($cur -ne (Get-AutoStartCommand)) { Set-AutoStart $true; Write-Log 'Démarrage avec Windows activé' }
        } elseif (Test-AutoStart) { Set-AutoStart $false }
    } catch { Write-Log "Démarrage avec Windows : $_" }
}

# ---------------------------------------------------------------------------
# Fenêtre et icône près de l'horloge
# ---------------------------------------------------------------------------
function Show-MainWindow {
    # (tests : la fenêtre reste hors de l'écran et ne prend jamais le premier plan, l'utilisateur garde la main)
    if ($EnTest) { return }
    try {
        if (-not $Window.IsVisible) { $Window.Show() }
        if ($Window.WindowState -eq 'Minimized') { $Window.WindowState = 'Normal' }
        # Passe devant toutes les fenêtres, puis redevient une fenêtre normale
        $Window.Topmost = $true; $Window.Topmost = $false
        [void]$Window.Activate()
    } catch { Write-Log "Affichage : $_" }
}

function Get-TrayIcon {
    if (-not $script:NotifyIcon) {
        $ni = New-Object System.Windows.Forms.NotifyIcon
        $ico = Join-Path $AppDir 'Evermind.ico'
        $ni.Icon = if (Test-Path -LiteralPath $ico) { New-Object System.Drawing.Icon (New-Object IO.MemoryStream (, [IO.File]::ReadAllBytes($ico))) } else { [System.Drawing.SystemIcons]::Information }
        $ni.Text = 'Evermind'
        $menu = New-Object System.Windows.Forms.ContextMenuStrip
        [void]$menu.Items.Add('Ouvrir Evermind', $null, { Show-MainWindow })
        [void]$menu.Items.Add('Quitter', $null, { Exit-App })
        $ni.ContextMenuStrip = $menu
        $ni.Add_MouseClick({ param($s, $e) if ([string]$e.Button -eq 'Left') { Show-MainWindow } })
        $ni.Add_BalloonTipClicked({ Show-MainWindow })
        $ni.Visible = $true
        $script:NotifyIcon = $ni
    }
    $script:NotifyIcon
}

# Notification : l'alerte d'Evermind (alerte.ps1), plus la bulle de Windows
function Show-Notify([string]$Title, [string]$Text) {
    if ($EnTest) { Write-Log "$Title : $Text"; return }
    Show-Alerte $Title $Text
}

# La croix ne ferme pas Evermind : il reste près de l'horloge pour donner les rappels.
function Hide-ToTray {
    $Window.Hide()
    if (-not (Get-Setting 'AstuceHorloge' $false)) {
        Set-Setting 'AstuceHorloge' $true
        Show-Notify 'Evermind reste près de l''horloge' 'Il veille sur tes rendez-vous. Clique sur son icône pour le rouvrir.'
    }
}

# La croix : demander (par défaut), ou ce qui a été retenu (« reduire », « quitter »)
function Invoke-Croix {
    switch ([string](Get-Setting 'Croix' '')) {
        'reduire' { Hide-ToTray }
        'quitter' { [void]$Window.Dispatcher.BeginInvoke([action]{ Exit-App }) }   # pas pendant la fermeture en cours
        default {
            $ui.ChkFermerRetenir.IsChecked = $false
            $ui.Fermer.Visibility = 'Visible'
            [void]$ui.BtnFermerReduire.Focus()
        }
    }
}

function Close-Fermer { $ui.Fermer.Visibility = 'Collapsed' }

function Invoke-FermerChoix([string]$Choix) {
    if ($ui.ChkFermerRetenir.IsChecked) { Set-Setting 'Croix' $Choix; Write-Log "Croix : $Choix (retenu)" }
    Close-Fermer
    if ($Choix -eq 'quitter') { Exit-App } else { Hide-ToTray }
}

# Réglages : ce que fait la croix
function Update-CroixReglage {
    $c = [string](Get-Setting 'Croix' '')
    $ui.CroixDemander.Tag = if (-not $c) { 'on' } else { $null }
    $ui.CroixReduire.Tag = if ($c -eq 'reduire') { 'on' } else { $null }
    $ui.CroixQuitter.Tag = if ($c -eq 'quitter') { 'on' } else { $null }
}

# Relance Evermind (nouveau thème) : il se ferme, puis Evermind.ps1 le relance une fois tout arrêté
# ---------------------------------------------------------------------------
# Mode jeu : quand un programme plein écran (un jeu, une vidéo) est au premier plan, Evermind se fait tout petit.
#   Priorité basse, l'IA et la voix rendues si elles ne servent pas (l'IA garde sinon ~2,5 Go de la carte graphique),
#   la mémoire inutilisée rendue à Windows. « OK Evermind » et Ctrl + Maj + Espace marchent toujours (l'IA se
#   recharge en quelques secondes si on lui demande quelque chose). Vérifié toutes les 4 secondes.
# ---------------------------------------------------------------------------
function Update-ModeJeu {
    $jeuPid = [EMJeu]::PleinEcran()
    $jeu = $jeuPid -ne 0
    $moi = [Diagnostics.Process]::GetCurrentProcess()
    if ($jeu -ne [bool]$script:ModeJeu) {
        $script:ModeJeu = $jeu
        if ($jeu) {
            $nom = try { (Get-Process -Id $jeuPid -ErrorAction Stop).ProcessName } catch { '?' }
            Write-Log "Mode jeu : $nom au premier plan, Evermind se fait discret"
            try { $moi.PriorityClass = 'BelowNormal' } catch {}
            Set-AnimationsPause $true
        } else {
            Write-Log 'Mode jeu : fini'
            try { $moi.PriorityClass = 'Normal' } catch {}
        }
    }
    if (-not $jeu) { return }
    # Pendant le jeu : ce qui ne sert pas est rendu (rien n'est coupé pendant une demande ou une phrase dite)
    $occupe = $script:Demande -or $script:Transcription -or $script:Parle -or $script:Ecoute
    if (-not $occupe) {
        if ($script:Cerveau -and ((Get-Date) - $script:Cerveau.Dernier).TotalSeconds -gt 60) { Stop-Cerveau; Write-Log 'Mode jeu : assistant mis en veille' }
        if ($script:Kokoro -and ((Get-Date) - $script:Kokoro.Dernier).TotalSeconds -gt 60) { Stop-KokoroServeur; Write-Log 'Mode jeu : voix mise en veille' }
    }
    if (-not $script:MemoireRendue -or ((Get-Date) - $script:MemoireRendue).TotalMinutes -ge 2) {
        $script:MemoireRendue = Get-Date
        [GC]::Collect()
        [EMJeu]::RendreMemoire($moi.Handle)
        if ($script:WhisperSrv -and -not $script:WhisperSrv.Process.HasExited) { try { [EMJeu]::RendreMemoire($script:WhisperSrv.Process.Handle) } catch {} }
    }
}

function Start-ModeJeu {
    if ($script:ModeJeuTimer -or $EnTest) { return }
    $script:ModeJeuTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:ModeJeuTimer.Interval = [TimeSpan]::FromSeconds(4)
    $script:ModeJeuTimer.Add_Tick({ try { Update-ModeJeu } catch { Write-Log "Mode jeu : $_" } })
    $script:ModeJeuTimer.Start()
}

function Restart-App {
    $script:Relancer = $true
    Exit-App
}

function Exit-App {
    if ($script:Quitting) { return }
    $script:Quitting = $true
    Write-Log 'Fermeture'
    try { if ($script:ShowWatch) { $script:ShowWatch.Stop() } } catch {}
    try { if ($script:Ecoute) { $script:Ecoute.Mic.Stop(); $script:Ecoute = $null } } catch {}
    try { if ($script:VoixHotkeyOk) { [EMNative]::RemoveHotKey((New-Object System.Windows.Interop.WindowInteropHelper $Window).Handle, $VoixHotkeyId) } } catch {}
    try { if ($script:Bulle) { $script:Bulle.Win.Close() } } catch {}
    try { if ($script:Synth) { $script:Synth.Dispose() } } catch {}
    try { Stop-Cerveau } catch {}
    try { Stop-KokoroServeur } catch {}
    try { Stop-WhisperServeur } catch {}
    try { Stop-Eveil } catch {}
    try { if ($script:LogoTimer) { $script:LogoTimer.Stop() } } catch {}
    try { if ($script:NotifyIcon) { $script:NotifyIcon.Visible = $false; $script:NotifyIcon.Dispose() } } catch {}
    try { $Window.Close() } catch {}
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown()
}
